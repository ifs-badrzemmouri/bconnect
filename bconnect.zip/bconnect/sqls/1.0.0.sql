CREATE TABLE IF NOT EXISTS public.users(
    id SERIAL PRIMARY KEY     NOT NULL,
    firstname    text,
    lastname    TEXT,
    email TEXT UNIQUE NOT NULL,
    password TEXT,
    accesspass TEXT,
    accesstoken TEXT,
    createddate TIMESTAMP,
    modifieddate TIMESTAMP,
    lastloggin  TIMESTAMP,
    neverlogged boolean,
    firstloggin boolean,
    isblocked boolean
);

CREATE TABLE IF NOT EXISTS public.application(
   id SERIAL PRIMARY KEY     NOT NULL,
   uuid text,
   name    text,
   description    TEXT,
   accessurl    TEXT
);

CREATE TABLE IF NOT EXISTS public.applicationmapping(
   id SERIAL PRIMARY KEY     NOT NULL,
   userId    INT,
   applicationId    INT
);

CREATE TABLE IF NOT EXISTS public.permissions(
   id SERIAL PRIMARY KEY     NOT NULL,
   name    text,
   description    TEXT
);

CREATE TABLE IF NOT EXISTS public.permissionsmapping(
   id SERIAL PRIMARY KEY     NOT NULL,
   userId    INT,
   permissionId    INT
);

insert into public.application(id, name, uuid) values(1, 'BoostConnectAdmin', '85b3-3a4f5571e87b');
insert into public.application(id, name, uuid) values(2, 'BoostChange', '9aa7-abe17302c50e');
insert into public.application(id, name, uuid) values(3, 'BoostAdmin', 'b381-429c3d6c950a');
insert into public.application(id, name, uuid) values(4, 'BoostEvent', '8518-f1e4c83461e0');
insert into public.application(id, name, uuid) values(5, 'XpZone', '9c7d-a2adbdbaae50');

insert into public.permissions(id, name) values(1, 'SUPER_ADMIN');
insert into public.permissions(id, name) values(2, 'CREATE_UPDATE_USERS');
insert into public.permissions(id, name) values(3 'FIND_USERS');
insert into public.permissions(id, name) values(4, 'SHOW_DASHBOARDSTATS');

insert into public.applicationmapping(userId, applicationId) values(1, 1);
insert into public.applicationmapping(userId, applicationId) values(1, 2);
insert into public.applicationmapping(userId, applicationId) values(1, 3);
insert into public.applicationmapping(userId, applicationId) values(1, 4);
insert into public.applicationmapping(userId, applicationId) values(1, 5);

insert into public.permissionsmapping(userId, permissionId) values(1, 1);
insert into public.permissionsmapping(userId, permissionId) values(1, 1);
insert into public.permissionsmapping(userId, permissionId) values(1, 1);
insert into public.permissionsmapping(userId, permissionId) values(1, 1);
insert into public.permissionsmapping(userId, permissionId) values(1, 1);

CREATE TABLE IF NOT EXISTS public.authentification(
   id SERIAL PRIMARY KEY     NOT NULL,
   userId    INT,
   applicationId INT,
   token    TEXT,
   refreshtoken text,
   expiration   TIMESTAMP
);

import jwt from 'jsonwebtoken';
import db from '../services/database';
import Helper from '../controllers/Helper';

const AuthMiddleware = {
    /**
     * Verify Token
     * @param {object} req
     * @param {string} req.headers
     * @param {object} req.user
     * @param {string} req.token
     * @param {string} req.tokenapplication
     * @param {object} req.application
     * @param {object} res
     * @param {function} next
     * @returns {object|void} response object
     */
    async verifyToken(req, res, next) {
        const token = req.headers['x-access-token'];
        const application = req.application;
        if (!token) {
            return res.status(401).send({'message': 'Token is not provided'});
        }
        try {
            /** @type {object} */
            const decoded = await jwt.verify(token, process.env.SECRET);
            const checkToken = 'SELECT * FROM authentification WHERE userId = $1 and token = $2 and applicationId = $3';
            const {rows} = await db.query(checkToken, [decoded.userId, token, application.id]);
            if (!rows[0]) {
                return res.status(401).send({'message': 'The token you provided is invalid'});
            }
            try {
                const text = 'SELECT * FROM users WHERE id = $1';
                const {rows} = await db.query(text, [decoded.userId]);
                if (!rows[0]) {
                    return res.status(401).send({'message': 'The token you provided is invalid'});
                }
                req.user = rows[0];
                req.token = token;
                req.tokenapplication = decoded.application;
                next();
            } catch (e) {
                return res.status(401).send(e);
            }
        } catch (error) {
            const removeQuery = 'Delete from authentification where token = $1 and applicationId = $2 returning *';
            const {rows} = await db.query(removeQuery, [token, application.id]);
            if (!rows[0]) {
                return res.status(401).send(error);
            }
            return res.status(401).send(error);
        }
    },

    /**
     * Verify Refresh Token
     * @param {object} req
     * @param {string} req.body.refreshtoken
     * @param {object} req.application
     * @param {object} req.user
     * @param {string} req.tokenrefreshapplication
     * @param {object} res
     * @param {function} next
     * @returns {object|void} response object
     */
    async verifyRefreshToken(req, res, next) {
        const refreshToken = req.body.refreshToken;
        const application = req.application;
        if (!refreshToken) {
            return res.status(401).send({'message': 'RefreshToken is not provided'});
        }
        try {
            /** @type {object} */
            const decoded = await jwt.verify(refreshToken, process.env.SECRET_REFRESH);
            const checkToken = 'SELECT * FROM authentification WHERE userId = $1 and refreshtoken = $2 and applicationId = $3';
            const {rows} = await db.query(checkToken, [decoded.userId, refreshToken, application.id]);
            if (!rows[0]) {
                return res.status(401).send({'message': 'The RefreshToken you provided is invalid'});
            }
            try {
                const removeQuery = 'Delete from authentification where userId = $1 and refreshtoken = $2 and applicationId = $3 returning *';
                const {rows} = await db.query(removeQuery, [decoded.userId, refreshToken, application.id]);
                if (!rows[0]) {
                    return res.status(401).send({message: 'The RefreshToken you provided is invalid'});
                }
                try {
                    const text = 'SELECT * FROM users WHERE id = $1';
                    const {rows} = await db.query(text, [decoded.userId]);
                    if (!rows[0]) {
                        return res.status(401).send({'message': 'The Refresh token you provided is invalid'});
                    }
                    req.user = rows[0];
                    req.tokenrefreshapplication = decoded.application;
                    next();
                } catch (e) {
                    return res.status(401).send(e);
                }
            } catch (e) {
                return res.status(401).send(e);
            }
        } catch (error) {
            const removeQuery = 'Delete from authentification where refreshtoken = $1 and applicationId = $2 returning *';
            const {rows} = await db.query(removeQuery, [refreshToken, application.id]);
            if (!rows[0]) {
                return res.status(401).send(error);
            }
            return res.status(401).send(error);
        }
    },

    /**
     * Verify Expose Token
     * @param {object} req
     * @param {string} req.body.accesstoken
     * @param {object} req.user
     * @param {object} res
     * @param {function} next
     * @returns {object|void} response object
     */
    async verifyExposeToken(req, res, next) {
        if (!req.body.accessToken) {
            return res.status(401).send({'message': 'AccessToken is missing'});
        }
        const token = req.body.accessToken;
        try {
            const text = 'SELECT * FROM users WHERE accesstoken = $1';
            const {rows} = await db.query(text, [token]);
            if (!rows[0]) {
                return res.status(401).send({'message': 'The AccessToken you provided is invalid'});
            }
            req.user = rows[0];
            next();
        } catch (e) {
            return res.status(401).send(e);
        }
    },

    /**
     * Verify Permission
     * @param {number} userId
     * @param {string} permission
     * @returns {boolean} response
     */
    async verifyPermission(userId, permission) {
        const findPermission = 'SELECT id FROM permissions WHERE name = $1';
        const findPermissionMap = 'SELECT * FROM permissionsmapping WHERE userId = $1 and permissionId = $2';
        try {
            const {rows} = await db.query(findPermission, ['SUPER_ADMIN']);
            if (!rows[0]) {
                return false;
            }
            let permissionId = rows[0].id;
            try {
                const {rows} = await db.query(findPermissionMap, [userId, permissionId]);
                if (!rows[0]) {
                    try {
                        const {rows} = await db.query(findPermission, [permission]);
                        if (!rows[0]) {
                            return false;
                        }
                        permissionId = rows[0].id;
                        try {
                            const {rows} = await db.query(findPermissionMap, [userId, permissionId]);
                            return rows[0];
                        } catch (errMapPerm) {
                            return false;
                        }
                    } catch (errPerm) {
                        return false;
                    }
                } else {
                    return true;
                }
            } catch (errPermMap) {
                return false;
            }
        } catch (errPerm) {
            return false;
        }
    },

    /**
     * Get Login User
     * @param {object} req
     * @param {string} req.body.email
     * @param {object} req.user
     * @param {object} res
     * @param {function} next
     * @returns {object|void} response object
     */
    async getLoginUser(req, res, next) {
        if (!req.body.email) {
            return res.status(401).send({'message': 'Email is missing'});
        }
        if (!Helper.isValidEmail(req.body.email)) {
            return res.status(401).send({'message': 'Please enter a valid email address'});
        }
        const findUser = 'SELECT * FROM users WHERE email = $1';
        try {
            const {rows} = await db.query(findUser, [req.body.email]);
            if (!rows[0]) {
                return res.status(401).send({'message': 'You are not allowed'});
            }
            const user = rows[0];
            if (user.isblocked) {
                return res.status(401).send({'message': 'You are not allowed'});
            } else {
                req.user = user;
                next();
            }
        } catch (errUser) {
            return res.status(401).send(errUser);
        }
    },

    /**
     * Get User Application Permission
     * @param {object} req
     * @param {number} req.user.id
     * @param {object} req.grants
     * @param {object} res
     * @param {function} next
     * @returns {object|void} response object
     */
    async getUserPermissions(req, res, next) {
        const userId = req.user.id;
        const findPermissions = 'select permissions.name from public.permissions, public.permissionsmapping ' +
            'where permissionsmapping.userid = $1 and permissionsmapping.permissionid = permissions.id';
        try {
            const {rows} = await db.query(findPermissions, [userId]);
            if (!rows[0]) {
                req.grants = [];
            } else {
                req.grants = rows;
            }
            next();
        } catch (error) {
            return res.status(401).send(error);
        }
    },

    /**
     * Get Application
     * @param {object} req
     * @param {string} req.body.application
     * @param {object} req.application
     * @param {object} res
     * @param {function} next
     * @returns {object|void} response object
     */
    async getApplication(req, res, next) {
        if (!req.body.application) {
            return res.status(401).send({'message': 'Application is missing'});
        }
        const application = req.body.application;
        const regExp = RegExp('^[a-z0-9]{4}-[a-z0-9]{12}$');
        if (regExp.test(application)) {
            const findApp = 'SELECT * FROM application WHERE uuid = $1';
            try {
                const {rows} = await db.query(findApp, [application]);
                if (!rows[0]) {
                    return res.status(401).send({'message': 'Application not found'});
                } else {
                    req.application = rows[0];
                    next();
                }
            } catch (error) {
                return res.status(401).send(error);
            }
        } else {
            return res.status(401).send({message: 'The Application you provided is invalid'});
        }
    },

    /**
     * Verify User Application
     * @param {object} req
     * @param {object} req.application
     * @param {object} req.user
     * @param {string} req.tokenapplication
     * @param {object} res
     * @param {function} next
     * @returns {object|void} response object
     */
    async verifyUserApplication(req, res, next) {
        const application = req.application;
        const user = req.user;
        const tokenapp = req.tokenapplication;
        let connected = true;
        if (tokenapp) {
            connected = tokenapp === application.uuid;
        }
        if (connected) {
            const findMapApp = 'SELECT * FROM applicationmapping WHERE userId = $1 and applicationId = $2';
            try {
                const {rows} = await db.query(findMapApp, [user.id, application.id]);
                if (!rows[0]) {
                    return res.status(401).send({'message': 'You are not allowed'});
                } else {
                    next();
                }
            } catch (error) {
                return res.status(401).send(error);
            }
        } else {
            return res.status(401).send({'message': 'You are not allowed'});
        }
    },

    /**
     * Verify User Application Refresh
     * @param {object} req
     * @param {object} req.application
     * @param {number} req.user.id
     * @param {string} req.tokenrefreshapplication
     * @param {object} res
     * @param {function} next
     * @returns {object|void} response object
     */
    async verifyUserApplicationRefresh(req, res, next) {
        const application = req.application;
        const userId = req.user.id;
        const tokenapp = req.tokenrefreshapplication;
        let connected = true;
        if (tokenapp) {
            connected = tokenapp === application.uuid;
        }
        if (connected) {
            const findMapApp = 'SELECT * FROM applicationmapping WHERE userId = $1 and applicationId = $2';
            try {
                const {rows} = await db.query(findMapApp, [userId, application.id]);
                if (!rows[0]) {
                    return res.status(401).send({'message': 'You are not allowed'});
                } else {
                    next();
                }
            } catch (error) {
                return res.status(401).send(error);
            }
        } else {
            return res.status(401).send({'message': 'You are not allowed'});
        }
    },
};

export default AuthMiddleware;

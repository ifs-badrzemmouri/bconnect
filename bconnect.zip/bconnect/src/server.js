import express from 'express';
import dotenv from 'dotenv';
import 'babel-polyfill';
import Authentification from './controllers/Authentification';
import User from './controllers/User';
import Application from './controllers/Application';
import Permission from './controllers/Permission';
import AuthMiddleware from './middleware/AuthMiddleware';
import bodyParser from 'body-parser';
import helmet from 'helmet';
import cors from 'cors';
import xss from 'xss-clean';
import frameguard from 'frameguard';
import nocache from 'nocache';
import xssFilter from 'x-xss-protection';
import hpp from 'hpp';
import RateLimit from 'express-rate-limit';
import session from 'express-session';

dotenv.config();
const port = Number.parseInt(process.env.PORT, 10);
const app = express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));
app.use(cors());
app.use(xss());
app.use(hpp());
app.use(frameguard());
app.use(nocache());
app.use(xssFilter({ setOnOldIE: true }));

const loginLimiter = new RateLimit({
    windowMs: 60 * 1000, // 1 minutes window
    max: 300, // start blocking after 300 requests
    handler: function (req, res) {
        res.status(429).send({error: {message: 'Too many request login from this IP, please try again after 1 minutes', statusCode: 429}});
    },
});

const emailLimiter = new RateLimit({
    windowMs: 2 * 60 * 1000, // 2 minutes window
    max: 200, // start blocking after 200 requests
    handler: function (req, res) {
        res.status(429).send({error: {message: 'Too many request sending email from this IP, please try again after 2 minutes', statusCode: 429}});
    },
});

function runningLocally(host) {
    return host === 'http://localhost:4404';
}

app.enable('trust proxy');
const sess = {
    secret: process.env.SESSION_SECRET,
    cookie: { secure: true, httponly: true },
    resave: true,
    saveUninitialized: true
};
app.use (function (req, res, next) {
    if(req.headers['x-forwarded-proto'] !== 'https' && process.env.NODE_ENV === 'production')
        res.redirect('https://' + req.get('host') + req.url);
    else
        next();
});

app.use(session(sess));
app.use(helmet.hsts({
    // Must be at least 1 year to be approved
    maxAge: 31536000,
    // Must be enabled to be approved
    includeSubDomains: true,
    preload: true,
}));
app.disable('x-powered-by');
app.use(helmet.frameguard({action: 'sameorigin'}));
app.use(helmet.noSniff());
app.use(helmet.referrerPolicy({policy: 'same-origin'}));
app.use(helmet.featurePolicy({
    features: {
        fullscreen: ["'self'"],
        vibrate: ["'none'"],
        payment: ["'none'"],
        syncXhr: ["'none'"]
    }
}));

app.use(function(req, res, next) {
    const host = req.headers.origin;
    if (runningLocally(host)) {
        res.setHeader('Access-Control-Allow-Origin', host);
    } else {
        res.setHeader('Access-Control-Allow-Origin', 'localhost');
    }
    res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    res.header('Access-Control-Allow-Credentials', true);
    next();
});

app.get('/', (req, res) => {
    return res.status(200).send({'message': 'Boostcoonect! Your first endpoint is working'});
});
// Authentification
app.post('/api/login', [AuthMiddleware.getApplication, AuthMiddleware.getLoginUser, AuthMiddleware.verifyUserApplication, loginLimiter], Authentification.login);
app.post('/api/loginaccess', [AuthMiddleware.getApplication, AuthMiddleware.getLoginUser, AuthMiddleware.verifyUserApplication, loginLimiter], Authentification.loginaccess);
app.post('/api/logindouble', [AuthMiddleware.getApplication, AuthMiddleware.getLoginUser, AuthMiddleware.verifyUserApplication, loginLimiter], Authentification.logindoublepass);
app.post('/api/loginurl', [AuthMiddleware.getApplication, AuthMiddleware.verifyExposeToken, AuthMiddleware.verifyUserApplication, loginLimiter], Authentification.loginurl);
app.post('/api/getloginurl', [AuthMiddleware.getApplication, AuthMiddleware.getLoginUser, AuthMiddleware.verifyUserApplication, loginLimiter], Authentification.getloginurl);
app.post('/api/getloginaccesspass', [AuthMiddleware.getApplication, AuthMiddleware.getLoginUser, AuthMiddleware.verifyUserApplication, emailLimiter], Authentification.getloginaccesspass);
app.post('/api/refresh', [AuthMiddleware.getApplication, AuthMiddleware.verifyRefreshToken, AuthMiddleware.verifyUserApplicationRefresh], Authentification.refreshToken);
app.post('/api/verify', [AuthMiddleware.getApplication, AuthMiddleware.verifyToken, AuthMiddleware.verifyUserApplication], Authentification.checkToken);
app.post('/api/logout', [AuthMiddleware.getApplication, AuthMiddleware.verifyToken, AuthMiddleware.verifyUserApplication], Authentification.logout);
// User
// create admin user
app.post('/api/users/createadmin', User.createAdmin);
app.post('/api/users/createuser', [AuthMiddleware.getApplication, AuthMiddleware.verifyToken, AuthMiddleware.verifyUserApplication], User.create);
app.post('/api/users/updateusers', [AuthMiddleware.getApplication, AuthMiddleware.verifyToken, AuthMiddleware.verifyUserApplication], User.updateusers);
app.post('/api/users/updatepassword', [AuthMiddleware.getApplication, AuthMiddleware.verifyToken, AuthMiddleware.verifyUserApplication], User.updatepassword);
app.post('/api/users/getallusers', [AuthMiddleware.getApplication, AuthMiddleware.verifyToken, AuthMiddleware.verifyUserApplication], User.findAllUsers);
app.post('/api/users/me', [AuthMiddleware.getApplication, AuthMiddleware.verifyToken, AuthMiddleware.verifyUserApplication, AuthMiddleware.getUserPermissions], User.findme);
app.post('/api/users/deleteuser', [AuthMiddleware.getApplication, AuthMiddleware.verifyToken, AuthMiddleware.verifyUserApplication], User.delete);
app.post('/api/users/getuserapplications', [AuthMiddleware.getApplication, AuthMiddleware.verifyToken, AuthMiddleware.verifyUserApplication], User.findUserApplications);
app.post('/api/users/adduserapplication', [AuthMiddleware.getApplication, AuthMiddleware.verifyToken, AuthMiddleware.verifyUserApplication], User.addUserApplication);
app.post('/api/users/deleteuserapplication', [AuthMiddleware.getApplication, AuthMiddleware.verifyToken, AuthMiddleware.verifyUserApplication], User.deleteUserApplication);
app.post('/api/users/getuserpermissions', [AuthMiddleware.getApplication, AuthMiddleware.verifyToken, AuthMiddleware.verifyUserApplication], User.findUserPermissions);
app.post('/api/users/adduserpermission', [AuthMiddleware.getApplication, AuthMiddleware.verifyToken, AuthMiddleware.verifyUserApplication], User.addUserPermission);
app.post('/api/users/deleteuserpermission', [AuthMiddleware.getApplication, AuthMiddleware.verifyToken, AuthMiddleware.verifyUserApplication], User.deleteUserPermission);

// Application
app.post('/api/application/createapplication', [AuthMiddleware.getApplication, AuthMiddleware.verifyToken, AuthMiddleware.verifyUserApplication], Application.create);
app.post('/api/application/getapplications', [AuthMiddleware.getApplication, AuthMiddleware.verifyToken, AuthMiddleware.verifyUserApplication], Application.findApplications);
app.post('/api/application/updateapplication', [AuthMiddleware.getApplication, AuthMiddleware.verifyToken, AuthMiddleware.verifyUserApplication], Application.update);
app.post('/api/application/deleteapplication', [AuthMiddleware.getApplication, AuthMiddleware.verifyToken, AuthMiddleware.verifyUserApplication], Application.delete);
// Permission
app.post('/api/permission/createpermission', [AuthMiddleware.getApplication, AuthMiddleware.verifyToken, AuthMiddleware.verifyUserApplication], Permission.create);
app.post('/api/permission/getpermissions', [AuthMiddleware.getApplication, AuthMiddleware.verifyToken, AuthMiddleware.verifyUserApplication], Permission.findPermissions);
app.post('/api/permission/updatepermission', [AuthMiddleware.getApplication, AuthMiddleware.verifyToken, AuthMiddleware.verifyUserApplication], Permission.update);
app.post('/api/permission/deletepermission', [AuthMiddleware.getApplication, AuthMiddleware.verifyToken, AuthMiddleware.verifyUserApplication], Permission.delete);


app.listen(port, () => {
    console.log('server started on port: ' + port);
});

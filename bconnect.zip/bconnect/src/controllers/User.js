import moment from 'moment';
import db from '../services/database';
import Helper from './Helper';
import AuthMiddleware from '../middleware/AuthMiddleware';

const User = {
    /**
     * Create User
     * @param {object} req
     * @param {string} req.body.email
     * @param {string} req.body.firstname
     * @param {string} req.body.lastname
     * @param {boolean} req.body.isblocked
     * @param {number} req.user.id
     * @param {object} res
     * @returns {object} token object
     */
    async create(req, res) {
        if (!req.body.email) {
            return res.status(401).send({'message': 'Email is missing'});
        }
        if (!Helper.isValidEmail(req.body.email)) {
            return res.status(401).send({ 'message': 'Please enter a valid email address' });
        }
        const password = 'Default00';
        const hashPassword = Helper.hashPassword(password);

        const userId = req.user.id;
        try {
            const hasPermission = await AuthMiddleware.verifyPermission(userId, 'CREATE_UPDATE_USERS');
            if (hasPermission) {
                const createQuery = 'INSERT INTO users(firstname, lastname, email, password, createddate, neverlogged, firstloggin, isblocked) VALUES($1, $2, $3, $4, $5, $6, $7, $8) returning *';
                const values = [
                    req.body.firstname,
                    req.body.lastname,
                    req.body.email,
                    hashPassword,
                    moment(new Date()),
                    true,
                    true,
                    req.body.isblocked,
                ];
                try {
                    const { rows } = await db.query(createQuery, values);
                    if (!rows[0]) {
                        return res.status(401).send({'message': 'Error create user'});
                    }
                    return res.status(201).send({ 'message': 'user created successfull' });
                } catch(error) {
                    if (error.routine === '_bt_check_unique') {
                        return res.status(401).send({ 'message': 'User with that EMAIL already exist' })
                    }
                    return res.status(401).send(error);
                }
            } else {
                return res.status(401).send({message: 'you are not allowed'});
            }
        } catch (e) {
            return res.status(401).send({message: 'you are not allowed'});
        }
    },

    /**
     * Create Admin User
     * @param {object} req
     * @param {object} res
     * @returns {object} token object
     */
    async createAdmin(req, res) {
        const password = 'Default00';
        const hashPassword = Helper.hashPassword(password);

        const createQuery = 'INSERT INTO users(id, firstname, lastname, email, password, createddate, neverlogged, firstloggin) VALUES($1, $2, $3, $4, $5, $6, $7, $8) returning *';
        const values = [
            1,
            'Boost',
            'Admin',
            'admin@lfc.com',
            hashPassword,
            moment(new Date()),
            false,
            false,
        ];
        try {
            const { rows } = await db.query(createQuery, values);
            if (!rows[0]) {
                return res.status(401).send({'message': 'Error create user'});
            }
            return res.status(201).send({ 'message': 'user created successfull' });
        } catch(error) {
            return res.status(401).send(error);
        }
    },

    /**
     * Delete A User
     * @param {object} req
     * @param {object} res
     * @returns {void} return status code 204
     */
    async delete(req, res) {
        if (!req.body.userId) {
            return res.status(401).send({'message': 'userId is missing'});
        }
        const userId = req.user.id;
        try {
            const hasPermission = await AuthMiddleware.verifyPermission(userId, 'DELETE_USERS');
            if (hasPermission) {
                const findQuery = 'select table_name from information_schema.columns where column_name = \'userid\';';
                try {
                    const { rows } = await db.query(findQuery, []);
                    if(!rows[0]) {
                        return res.status(404).send({'message': 'no user found in tables'});
                    }
                    for (let i = 0; i < rows.length; i++) {
                        /** @param {{table_name: string}} rows  */
                        const deleteTableQuery = 'DELETE FROM ' + rows[i].table_name + ' WHERE userId = $1 returning *';
                        try {
                            await db.query(deleteTableQuery, [req.body.userId]);
                            // eslint-disable-next-line no-empty
                        } catch (e) {}
                    }
                    const deleteQuery = 'DELETE FROM users WHERE id=$1 returning *';
                    try {
                        const { rows } = await db.query(deleteQuery, [req.body.userId]);
                        if(!rows[0]) {
                            return res.status(404).send({'message': 'user not found'});
                        }
                        return res.status(200).send({ 'message': 'user deleted successful' });
                    } catch(error) {
                        return res.status(400).send(error);
                    }
                } catch(error) {
                    return res.status(400).send(error);
                }
            } else {
                return res.status(401).send({message: 'you are not allowed'});
            }
        } catch (e) {
            return res.status(401).send({message: 'you are not allowed'});
        }
    },

    /**
     * Update password
     * @param {object} req
     * @param {object} req.user
     * @param {string} req.body.password
     * @param {object} res
     * @returns {object} user object
     */
    async updatepassword(req, res) {
        if (!req.body.password) {
            return res.status(400).send({'message': 'Password is missing'});
        }
        const user = req.user;
        const hashPassword = Helper.hashPassword(req.body.password);
        const text = 'SELECT * FROM users WHERE id = $1';
        try {
            const { rows } = await db.query(text, [user.id]);
            if (!rows[0]) {
                return res.status(400).send({'message': 'Some values are missing'});
            }
            try {
                const updateQuery = 'UPDATE users set password = $1, firstloggin = $2, modifieddate = $3 where id = $4 returning *';
                const { rows } = await db.query(updateQuery, [hashPassword, false,  moment(new Date()), user.id]);
                if (!rows[0]) {
                    return res.status(400).send({'message': 'Error update user password'});
                }
                return res.status(200).send({ message: 'user password update success' });
            } catch (e) {
                return res.status(400).send(e);
            }
        } catch(error) {
            return res.status(400).send(error);
        }
    },

    /**
     * Update Users
     * @param {object} req
     * @param {string} req.body.userId
     * @param {string} req.body.email
     * @param {string} req.body.firstname
     * @param {string} req.body.lastname
     * @param {boolean} req.body.isblocked
     * @param {number} req.user.id
     * @param {object} res
     * @returns {object} response
     */
    async updateusers(req, res) {
        if (!req.body.email) {
            return res.status(401).send({'message': 'Email is missing'});
        }
        if (!req.body.firstname) {
            return res.status(401).send({'message': 'Firstname is missing'});
        }
        if (!req.body.lastname) {
            return res.status(401).send({'message': 'Lastname is missing'});
        }
        if (!req.body.userId) {
            return res.status(401).send({'message': 'userId is missing'});
        }
        if (!Helper.isValidEmail(req.body.email)) {
            return res.status(401).send({ 'message': 'Please enter a valid email address' });
        }
        const userId = req.user.id;
        try {
            const hasPermission = await AuthMiddleware.verifyPermission(userId, 'CREATE_UPDATE_USERS');
            if (hasPermission) {
                const updateQuery = 'update users set firstname = $1, lastname = $2, email = $3, modifieddate = $4, isblocked = $5 where id = $6 returning *';
                const values = [
                    req.body.firstname,
                    req.body.lastname,
                    req.body.email,
                    moment(new Date()),
                    req.body.isblocked,
                    req.body.userId
                ];
                try {
                    const { rows } = await db.query(updateQuery, values);
                    if (!rows[0]) {
                        return res.status(401).send({'message': 'Error update user'});
                    }
                    return res.status(201).send({ 'message': 'user updated successfull' });
                } catch(error) {
                    return res.status(401).send(error);
                }
            } else {
                return res.status(401).send({message: 'you are not allowed'});
            }
        } catch (e) {
            return res.status(401).send({message: 'you are not allowed'});
        }
    },

    /**
     * Find Users
     * @param {object} req
     * @param {object} res
     * @returns {object} user object
     */
    async findAllUsers(req, res) {
        const userId = req.user.id;
        try {
            const hasPermission = await AuthMiddleware.verifyPermission(userId, 'FIND_USERS');
            if (hasPermission) {
                const text = 'SELECT id, firstname, lastname, email, createddate, modifieddate, lastloggin, neverlogged, firstloggin, isblocked FROM users order by id ASC';
                try {
                    const { rows } = await db.query(text, []);
                    return res.status(200).send({ users: rows });
                } catch(error) {
                    return res.status(401).send(error);
                }
            } else {
                return res.status(401).send({message: 'you are not allowed'});
            }
        } catch (e) {
            return res.status(401).send({message: 'you are not allowed'});
        }
    },

    /**
     * find me
     * @param {object} req
     * @param {number} req.user.id
     * @param {object} req.grants
     * @param {{uuid: string}} req.application
     * @param {object} res
     * @returns {object} user object
     */
    async findme(req, res) {
        const userId = req.user.id;
        const grants = req.grants;
        const application = req.application;
        try {
            const findQuery = 'SELECT * from users where id = $1';
            const { rows } = await db.query(findQuery, [userId]);
            if (!rows[0]) {
                return res.status(401).send({'message': 'Error Find user'});
            }
            const usertmp = rows[0];
            const user = {
                id: usertmp.id,
                firstname: usertmp.firstname,
                lastname: usertmp.lastname,
                email: usertmp.email,
                lastloggin: usertmp.lastloggin,
                neverlogged: usertmp.neverlogged,
                firstloggin: usertmp.firstloggin,
                createddate: usertmp.createddate,
                modifieddate: usertmp.modifieddate,
            };
            const obj = {
                user: user,
                application: application.uuid,
                grants: grants
            };
            return res.status(200).send(obj);
        } catch(error) {
            return res.status(401).send(error);
        }
    },

    /**
     * Find User Applications
     * @param {object} req
     * @param {object} res
     * @returns {object} user object
     */
    async findUserApplications(req, res) {
        const userId = req.user.id;
        if (!req.body.userId) {
            return res.status(401).send({'message': 'userId is missing'});
        }
        try {
            const hasPermission = await AuthMiddleware.verifyPermission(userId, 'FIND_USER_APPLICATIONS');
            if (hasPermission) {
                const findQuery = 'select application.id, name, uuid from application, applicationmapping where userid = $1 and applicationid = application.id order by name ASC';
                try {
                    const { rows } = await db.query(findQuery, [req.body.userId]);
                    return res.status(200).send({ applications: rows });
                } catch(error) {
                    return res.status(400).send(error);
                }
            } else {
                return res.status(401).send({message: 'you are not allowed'});
            }
        } catch (e) {
            return res.status(401).send({message: 'you are not allowed'});
        }
    },

    /**
     * Find User Permissions
     * @param {object} req
     * @param {object} res
     * @returns {object} user object
     */
    async findUserPermissions(req, res) {
        if (!req.body.userId) {
            return res.status(401).send({'message': 'userId is missing'});
        }
        const userId = req.user.id;
        try {
            const hasPermission = await AuthMiddleware.verifyPermission(userId, 'FIND_USER_PERMISSIONS');
            if (hasPermission) {
                const findQuery = 'select permissions.id, name from permissions, permissionsmapping where permissionid = permissions.id and userid = $1 order by name ASC';
                try {
                    const { rows } = await db.query(findQuery, [req.body.userId]);
                    return res.status(200).send({ permissions: rows });
                } catch(error) {
                    return res.status(400).send(error);
                }
            } else {
                return res.status(401).send({message: 'you are not allowed'});
            }
        } catch (e) {
            return res.status(401).send({message: 'you are not allowed'});
        }
    },

    /**
     * Add User Application
     * @param {object} req
     * @param {object} res
     * @returns {object} user object
     */
    async addUserApplication(req, res) {
        if (!req.body.userId) {
            return res.status(401).send({'message': 'userId is missing'});
        }
        if (!req.body.applicationId) {
            return res.status(401).send({'message': 'applicationId is missing'});
        }
        const userId = req.user.id;
        try {
            const hasPermission = await AuthMiddleware.verifyPermission(userId, 'ADD_USER_APPLICATIONS');
            if (hasPermission) {
                const findQuery = 'SELECT * FROM applicationmapping where userId = $1 and applicationId = $2';
                try {
                    const { rows } = await db.query(findQuery, [req.body.userId, req.body.applicationId]);
                    if (!rows[0]) {
                        const createQuery = 'INSERT INTO applicationmapping(userId, applicationId) VALUES($1, $2) returning *';
                        try {
                            const { rows } = await db.query(createQuery, [req.body.userId, req.body.applicationId]);
                            if (!rows[0]) {
                                return res.status(401).send({'message': 'Error add application to user'});
                            }
                            return res.status(201).send({ message: 'application added to user' });
                        } catch(error) {
                            return res.status(400).send(error);
                        }
                    } else {
                        return res.status(201).send({'message': 'User already granted to this application'});
                    }
                } catch (err) {
                    return res.status(400).send(err);
                }
            } else {
                return res.status(401).send({message: 'you are not allowed'});
            }
        } catch (e) {
            return res.status(401).send({message: 'you are not allowed'});
        }
    },

    /**
     * Delete User Application
     * @param {object} req
     * @param {object} res
     * @returns {object} user object
     */
    async deleteUserApplication(req, res) {
        if (!req.body.userId) {
            return res.status(401).send({'message': 'userId is missing'});
        }
        if (!req.body.applicationId) {
            return res.status(401).send({'message': 'applicationId is missing'});
        }
        const userId = req.user.id;
        try {
            const hasPermission = await AuthMiddleware.verifyPermission(userId, 'DELETE_USER_APPLICATIONS');
            if (hasPermission) {
                const deleteQuery = 'DELETE FROM applicationmapping where userId = $1 and applicationId = $2 returning *';
                try {
                    const { rows } = await db.query(deleteQuery, [req.body.userId, req.body.applicationId]);
                    if (!rows[0]) {
                        return res.status(401).send({'message': 'Error remove user grant from this application'});
                    } else {
                        return res.status(200).send({'message': 'User remove granted from this application'});
                    }
                } catch (err) {
                    return res.status(400).send(err);
                }
            } else {
                return res.status(401).send({message: 'you are not allowed'});
            }
        } catch (e) {
            return res.status(401).send({message: 'you are not allowed'});
        }
    },

    /**
     * Add User Permission
     * @param {object} req
     * @param {object} res
     * @returns {object} user object
     */
    async addUserPermission(req, res) {
        if (!req.body.userId) {
            return res.status(401).send({'message': 'userId is missing'});
        }
        if (!req.body.permissionId) {
            return res.status(401).send({'message': 'permissionId is missing'});
        }
        const userId = req.user.id;
        try {
            const hasPermission = await AuthMiddleware.verifyPermission(userId, 'ADD_USER_PERMISSIONS');
            if (hasPermission) {
                const findQuery = 'SELECT * FROM permissionsmapping where userId = $1 and permissionId = $2';
                try {
                    const { rows } = await db.query(findQuery, [req.body.userId, req.body.permissionId]);
                    if (!rows[0]) {
                        const createQuery = 'INSERT INTO permissionsmapping(userId, permissionId) VALUES($1, $2) returning *';
                        try {
                            const { rows } = await db.query(createQuery, [req.body.userId, req.body.permissionId]);
                            if (!rows[0]) {
                                return res.status(401).send({'message': 'Error add permission to user'});
                            }
                            return res.status(201).send({ message: 'permission added to user' });
                        } catch(error) {
                            return res.status(400).send(error);
                        }
                    } else {
                        return res.status(201).send({'message': 'User already has this permission'});
                    }
                } catch (err) {
                    return res.status(400).send(err);
                }
            } else {
                return res.status(401).send({message: 'you are not allowed'});
            }
        } catch (e) {
            return res.status(401).send({message: 'you are not allowed'});
        }
    },

    /**
     * Delete User Permission
     * @param {object} req
     * @param {object} res
     * @returns {object} user object
     */
    async deleteUserPermission(req, res) {
        if (!req.body.userId) {
            return res.status(401).send({'message': 'userId is missing'});
        }
        if (!req.body.permissionId) {
            return res.status(401).send({'message': 'permissionId is missing'});
        }
        const userId = req.user.id;
        try {
            const hasPermission = await AuthMiddleware.verifyPermission(userId, 'DELETE_USER_PERMISSIONS');
            if (hasPermission) {
                const deleteQuery = 'DELETE FROM permissionsmapping where userId = $1 and permissionId = $2 returning *';
                try {
                    const { rows } = await db.query(deleteQuery, [req.body.userId, req.body.permissionId]);
                    if (!rows[0]) {
                        return res.status(401).send({'message': 'Error remove user permission'});
                    } else {
                        return res.status(200).send({'message': 'User remove permission success'});
                    }
                } catch (err) {
                    return res.status(400).send(err);
                }
            } else {
                return res.status(401).send({message: 'you are not allowed'});
            }
        } catch (e) {
            return res.status(401).send({message: 'you are not allowed'});
        }
    },

};

export default User;

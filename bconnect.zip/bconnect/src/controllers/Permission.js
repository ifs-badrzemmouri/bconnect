import db from '../services/database';
import AuthMiddleware from '../middleware/AuthMiddleware';

const Permission = {
    /**
     * Create Permission
     * @param {object} req
     * @param {string} req.body.name
     * @param {string} req.body.description
     * @param {number} req.user.id
     * @param {object} res
     * @returns {object} response
     */
    async create(req, res) {
        if (!req.body.name) {
            return res.status(401).send({'message': 'Name is missing'});
        }
        let description = req.body.description;
        if (description === '' || description === 'null') {
            description = null;
        }
        const userId = req.user.id;
        try {
            const hasPermission = await AuthMiddleware.verifyPermission(userId, 'CREATE_UPDATE_PERMISSIONS');
            if (hasPermission) {
                const createQuery = 'INSERT INTO permissions(name, description) VALUES($1, $2) returning *';
                const values = [
                    req.body.name,
                    description
                ];
                try {
                    const { rows } = await db.query(createQuery, values);
                    if (!rows[0]) {
                        return res.status(401).send({'message': 'Error create permission'});
                    }
                    return res.status(201).send({ 'message': 'permission created successfull' });
                } catch(error) {
                    return res.status(401).send(error);
                }
            } else {
                return res.status(401).send({message: 'you are not allowed'});
            }
        } catch (e) {
            return res.status(401).send({message: 'you are not allowed'});
        }
    },

    /**
     * Find Permission
     * @param {object} req
     * @param {object} res
     * @returns {object} permissions
     */
    async findPermissions(req, res) {
        const userId = req.user.id;
        try {
            const hasPermission = await AuthMiddleware.verifyPermission(userId, 'FIND_PERMISSIONS');
            if (hasPermission) {
                const text = 'SELECT * FROM permissions order by name ASC';
                try {
                    const { rows } = await db.query(text, []);
                    return res.status(200).send({ permissions: rows });
                } catch(error) {
                    return res.status(400).send(error);
                }
            } else {
                return res.status(401).send({message: 'you are not allowed'});
            }
        } catch (e) {
            return res.status(401).send({message: 'you are not allowed'});
        }
    },

    /**
     * Update Permission
     * @param {object} req
     * @param {string} req.body.name
     * @param {string} req.body.description
     * @param {number} req.body.permissionId
     * @param {number} req.user.id
     * @param {object} res
     * @returns {object} response
     */
    async update(req, res) {
        if (!req.body.name) {
            return res.status(401).send({'message': 'Name is missing'});
        }
        if (!req.body.permissionId) {
            return res.status(401).send({'message': 'PermissionId is missing'});
        }
        let description = req.body.description;
        if (description === '' || description === 'null') {
            description = null;
        }
        const userId = req.user.id;
        try {
            const hasPermission = await AuthMiddleware.verifyPermission(userId, 'CREATE_UPDATE_PERMISSIONS');
            if (hasPermission) {
                const updateQuery = 'UPDATE permissions set name = $1, description = $2 where id = $3 returning *';
                const values = [
                    req.body.name,
                    description,
                    req.body.permissionId
                ];
                try {
                    const { rows } = await db.query(updateQuery, values);
                    if (!rows[0]) {
                        return res.status(401).send({'message': 'Error update permission'});
                    }
                    return res.status(201).send({ 'message': 'permission updated successfull' });
                } catch(error) {
                    return res.status(401).send(error);
                }
            } else {
                return res.status(401).send({message: 'you are not allowed'});
            }
        } catch (e) {
            return res.status(401).send({message: 'you are not allowed'});
        }
    },

    /**
     * Delete Permission
     * @param {object} req
     * @param {number} req.body.permissionId
     * @param {number} req.user.id
     * @param {object} res
     * @returns {object} token object
     */
    async delete(req, res) {
        if (!req.body.permissionId) {
            return res.status(401).send({'message': 'PermissionId is missing'});
        }
        const userId = req.user.id;
        try {
            const hasPermission = await AuthMiddleware.verifyPermission(userId, 'DELETE_PERMISSIONS');
            if (hasPermission) {
                const deleteQuery = 'Delete from permissions where id = $1 returning *';
                const values = [
                    req.body.permissionId
                ];
                try {
                    const { rows } = await db.query(deleteQuery, values);
                    if (!rows[0]) {
                        return res.status(401).send({'message': 'Error delete permission'});
                    }
                    return res.status(201).send({ 'message': 'permission deleted successfull' });
                } catch(error) {
                    return res.status(401).send(error);
                }
            } else {
                return res.status(401).send({message: 'you are not allowed'});
            }
        } catch (e) {
            return res.status(401).send({message: 'you are not allowed'});
        }
    },
};

export default Permission;

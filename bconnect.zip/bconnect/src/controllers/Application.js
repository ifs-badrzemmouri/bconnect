import db from '../services/database';
import Helper from './Helper';
import AuthMiddleware from '../middleware/AuthMiddleware';

const Application = {
    /**
     * Create Application
     * @param {object} req
     * @param {string} req.body.name
     * @param {string} req.body.description
     * @param {string} req.body.accessurl
     * @param {number} req.user.id
     * @param {object} res
     * @returns {object} response
     */
    async create(req, res) {
        if (!req.body.name) {
            return res.status(401).send({'message': 'Name is missing'});
        }
        let description = req.body.description;
        if (description === '' || description === 'null') {
            description = null;
        }
        const uuid = Helper.generateAppuuid();
        const userId = req.user.id;
        try {
            const hasPermission = await AuthMiddleware.verifyPermission(userId, 'CREATE_UPDATE_APPLICATIONS');
            if (hasPermission) {
                const createQuery = 'INSERT INTO application(uuid, name, description, accessurl) VALUES($1, $2, $3, $4) returning *';
                const values = [
                    uuid,
                    req.body.name,
                    description,
                    req.body.accessurl
                ];
                try {
                    const { rows } = await db.query(createQuery, values);
                    if (!rows[0]) {
                        return res.status(401).send({'message': 'Error create application'});
                    }
                    return res.status(201).send({ 'message': 'application created successfull' });
                } catch(error) {
                    return res.status(401).send(error);
                }
            } else {
                return res.status(401).send({message: 'you are not allowed'});
            }
        } catch (e) {
            return res.status(401).send({message: 'you are not allowed'});
        }
    },

    /**
     * Find Application
     * @param {object} req
     * @param {object} res
     * @returns {object} applications
     */
    async findApplications(req, res) {
        const userId = req.user.id;
        try {
            const hasPermission = await AuthMiddleware.verifyPermission(userId, 'FIND_APPLICATIONS');
            if (hasPermission) {
                const text = 'SELECT * FROM application order by name ASC';
                try {
                    const { rows } = await db.query(text, []);
                    return res.status(200).send({ applications: rows });
                } catch(error) {
                    return res.status(400).send(error);
                }
            } else {
                return res.status(401).send({message: 'you are not allowed'});
            }
        } catch (e) {
            return res.status(401).send({message: 'you are not allowed'});
        }
    },

    /**
     * Update Application
     * @param {object} req
     * @param {object} res
     * @param {string} req.body.name
     * @param {string} req.body.description
     * @param {string} req.body.accessurl
     * @param {number} req.body.applicationId
     * @param {number} req.user.id
     * @returns {object} response
     */
    async update(req, res) {
        if (!req.body.name) {
            return res.status(401).send({'message': 'Name is missing'});
        }
        if (!req.body.applicationId) {
            return res.status(401).send({'message': 'ApplicationId is missing'});
        }
        let description = req.body.description;
        if (description === '' || description === 'null') {
            description = null;
        }
        const userId = req.user.id;
        try {
            const hasPermission = await AuthMiddleware.verifyPermission(userId, 'CREATE_UPDATE_APPLICATIONS');
            if (hasPermission) {
                const updateQuery = 'UPDATE application set name = $1, description = $2, accessurl = $3 where id = $4 returning *';
                const values = [
                    req.body.name,
                    description,
                    req.body.accessurl,
                    req.body.applicationId
                ];
                try {
                    const { rows } = await db.query(updateQuery, values);
                    if (!rows[0]) {
                        return res.status(401).send({'message': 'Error update application'});
                    }
                    return res.status(201).send({ 'message': 'application updated successfull' });
                } catch(error) {
                    return res.status(401).send(error);
                }
            } else {
                return res.status(401).send({message: 'you are not allowed'});
            }
        } catch (e) {
            return res.status(401).send({message: 'you are not allowed'});
        }
    },

    /**
     * Delete Application
     * @param {object} req
     * @param {number} req.body.applicationId
     * @param {number} req.user.id
     * @param {object} res
     * @returns {object} response
     */
    async delete(req, res) {
        if (!req.body.applicationId) {
            return res.status(401).send({'message': 'ApplicationId is missing'});
        }
        const userId = req.user.id;
        try {
            const hasPermission = await AuthMiddleware.verifyPermission(userId, 'DELETE_APPLICATIONS');
            if (hasPermission) {
                const deleteQuery = 'Delete from application where id = $1 returning *';
                const values = [
                    req.body.applicationId
                ];
                try {
                    const { rows } = await db.query(deleteQuery, values);
                    if (!rows[0]) {
                        return res.status(401).send({'message': 'Error delete application'});
                    }
                    return res.status(201).send({ 'message': 'application deleted successfull' });
                } catch(error) {
                    return res.status(401).send(error);
                }
            } else {
                return res.status(401).send({message: 'you are not allowed'});
            }
        } catch (e) {
            return res.status(401).send({message: 'you are not allowed'});
        }
    },
};

export default Application;

import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';

function randomString(len) {
    const charSet = 'abcdefghijklmnopqrstuvwxyz0123456789';
    let randomString = '';
    for (let i = 0; i < len; i++) {
        const randomPoz = Math.floor(Math.random() * charSet.length);
        randomString += charSet.substring(randomPoz, randomPoz + 1);
    }
    return randomString;
}

const Helper = {
    /**
     * Hash Password Method
     * @param {string} password
     * @returns {string} returns hashed password
     */
    hashPassword(password) {
        return bcrypt.hashSync(password, bcrypt.genSaltSync(8));
    },

    /**
     * comparePassword
     * @param {string} hashPassword
     * @param {string} password
     * @returns {Boolean} return True or False
     */
    comparePassword(hashPassword, password) {
        return bcrypt.compareSync(password, hashPassword);
    },

    /**
     * isValidEmail helper method
     * @param {string} email
     * @returns {Boolean} True or False
     */
    isValidEmail(email) {
        return /\S+@\S+\.\S+/.test(email);
    },

    /**
     * Gnerate Token
     * @param {object} obj
     * @returns {string} token
     */
    generateToken(obj) {
        return jwt.sign(obj, process.env.SECRET, {expiresIn: '1h'});
    },

    /**
     * Gnerate Refresh Token
     * @param {string} id
     * @returns {string} token
     */
    generateRefreshToken(id) {
        return jwt.sign({userId: id}, process.env.SECRET_REFRESH, {expiresIn: '1h'});
    },

    /**
     * Generate App uuid
     * @returns {string} uuid
     */
    generateAppuuid() {
        return randomString(4) + '-' + randomString(12);
    },

    /**
     * Generate User Expose Token
     * @returns {string} token
     */
    generateUserExposeToken() {
        return randomString(256);
    }
};

export default Helper;

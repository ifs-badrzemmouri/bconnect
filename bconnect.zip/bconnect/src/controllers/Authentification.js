import moment from 'moment';
import db from '../services/database';
import Helper from './Helper';
import utils from '../services/utils';
import jwt from 'jsonwebtoken';

const Authentification = {
    /**
     * Login with password
     * @param {object} req
     * @param {string} req.body.password
     * @param {object} req.user
     * @param {{uuid: string}} req.application
     * @param {object} res
     * @returns {object} user object
     */
    async login(req, res) {
        if (!req.body.password) {
            return res.status(401).send({'message': 'Password is missing'});
        }
        const user = req.user;
        const application = req.application;
        if(!Helper.comparePassword(user.password, req.body.password)) {
            return res.status(401).send({ 'message': 'The credentials you provided is incorrect' });
        }
        try {
            const updateQuery = 'UPDATE users set neverlogged = $1, lastloggin = $2 where id = $3 returning *';
            const { rows } = await db.query(updateQuery, [false,  moment(new Date()), user.id]);
            if (!rows[0]) {
                return res.status(401).send({'message': 'Error Login user'});
            }
            const obj = {
                userId: user.id,
                application: application.uuid,
            };
            const token = Helper.generateToken(obj);
            /** @type {object} */
            const decoded = await jwt.verify(token, process.env.SECRET);
            const refreshToken = Helper.generateRefreshToken(user.id);
            const expiration = new Date(0);
            expiration.setUTCSeconds(decoded.exp);
            try {
                const createQuery = 'INSERT INTO authentification(userId, applicationId, token, refreshtoken, expiration) VALUES($1, $2, $3, $4, $5) returning *';
                const { rows } = await db.query(createQuery, [user.id, application.id, token, refreshToken, expiration]);
                if (!rows[0]) {
                    return res.status(401).send({'message': 'Error Login user'});
                }
                return res.status(200).send({ token, refreshToken });
            } catch (e) {
                return res.status(401).send(e);
            }
        } catch (error) {
            return res.status(401).send(error);
        }
    },

    /**
     * Login with accesspass
     * @param {object} req
     * @param {object} req.user
     * @param {{uuid: string}} req.application
     * @param {string} req.body.accesspass
     * @param {object} res
     * @returns {object} user object
     */
    async loginaccess(req, res) {
        const user = req.user;
        const application = req.application;
        if (!req.body.accesspass) {
            return res.status(400).send({'message': 'Access Pass is missing'});
        }
        if(!Helper.comparePassword(user.accesspass, req.body.accesspass)) {
            return res.status(400).send({ 'message': 'The Access Pass you provided is incorrect' });
        }
        try {
            const updateQuery = 'UPDATE users set neverlogged = $1, lastloggin = $2, accesspass = $3 where id = $4 returning *';
            const { rows } = await db.query(updateQuery, [false,  moment(new Date()), null, user.id]);
            if (!rows[0]) {
                return res.status(400).send({'message': 'Error Login access pass user'});
            }
            const obj = {
                userId: user.id,
                application: application.uuid,
            };
            const token = Helper.generateToken(obj);
            /** @type {object} */
            const decoded = await jwt.verify(token, process.env.SECRET);
            const refreshToken = Helper.generateRefreshToken(user.id);
            const expiration = new Date(0);
            expiration.setUTCSeconds(decoded.exp);
            try {
                const createQuery = 'INSERT INTO authentification(userId, applicationId, token, refreshtoken, expiration) VALUES($1, $2, $3, $4, $5) returning *';
                const { rows } = await db.query(createQuery, [user.id, application.id, token, refreshToken, expiration]);
                if (!rows[0]) {
                    return res.status(401).send({'message': 'Error Login access pass user'});
                }
                return res.status(200).send({ token, refreshToken });
            } catch (e) {
                return res.status(401).send(e);
            }
        } catch (e) {
            return res.status(400).send(e);
        }
    },

    /**
     * Login double Auth
     * @param {object} req
     * @param {string} req.body.password
     * @param {object} req.user
     * @param {object} res
     * @returns {object} user object
     */
    async logindoublepass(req, res) {
        if (!req.body.password) {
            return res.status(401).send({'message': 'Password is missing'});
        }
        const user = req.user;
        if(!Helper.comparePassword(user.password, req.body.password)) {
            return res.status(401).send({ 'message': 'The credentials you provided is incorrect' });
        }
        try {
            await Authentification.getloginaccesspass(req, res);
        } catch (e) {
            return res.status(400).send(e);
        }
    },

    /**
     * Login with url
     * @param {object} req
     * @param {object} req.user
     * @param {{uuid: string}} req.application
     * @param {object} res
     * @returns {object} user object
     */
    async loginurl(req, res) {
        const user = req.user;
        const application = req.application;
        try {
            const updateQuery = 'UPDATE users set accesstoken = $1, lastloggin = $2 where id = $3 returning *';
            const { rows } = await db.query(updateQuery, [null, moment(new Date()), user.id]);
            if (!rows[0]) {
                return res.status(400).send({'message': 'Error Login url user'});
            }
            const obj = {
                userId: user.id,
                application: application.uuid,
            };
            const token = Helper.generateToken(obj);
            /** @type {object} */
            const decoded = await jwt.verify(token, process.env.SECRET);
            const refreshToken = Helper.generateRefreshToken(user.id);
            const expiration = new Date(0);
            expiration.setUTCSeconds(decoded.exp);
            try {
                const createQuery = 'INSERT INTO authentification(userId, applicationId, token, refreshtoken, expiration) VALUES($1, $2, $3, $4, $5) returning *';
                const { rows } = await db.query(createQuery, [user.id, application.id, token, refreshToken, expiration]);
                if (!rows[0]) {
                    return res.status(401).send({'message': 'Error Login url user'});
                }
                return res.status(200).send({ token, refreshToken });
            } catch (e) {
                return res.status(401).send(e);
            }
        } catch (e) {
            return res.status(400).send(e);
        }
    },

    /**
     * Send user Login With Url
     * @param {object} req
     * @param {object} req.user
     * @param {{homeurl: string}} req.application
     * @param {object} res
     * @returns {object} user object
     */
    async getloginurl(req, res) {
        const user = req.user;
        const application = req.application;
        const token = Helper.generateUserExposeToken();
        try {
            try {
                const updateQuery = 'UPDATE users set accesstoken = $1 where id = $2 returning *';
                const { rows } = await db.query(updateQuery, [token, user.id]);
                if (!rows[0]) {
                    return res.status(400).send({'message': 'Error Login with Access Url'});
                }
                const url = application.accessurl + '/' + token;
                const sendMessage = 'Hello, \nTo access the application click in this link: ' + url;
                const mailOptions = {
                    from: 'BoostConnect <boost@bnppboostchange.com>',
                    to: user.email,
                    subject: 'BoostConnect Access Url',
                    text: sendMessage,
                };
                const result = await utils.sendEmail(mailOptions);
                if (result) {
                    return res.status(200).send({message: 'email sent successfull'});
                } else {
                    return res.status(401).send({'message': 'error sent email'});
                }
            } catch (err) {
                return res.status(400).send(err);
            }
        } catch (e) {
            return res.status(400).send(e);
        }
    },

    /**
     * Send user access accesspass
     * @param {object} req
     * @param {object} req.user
     * @param {object} res
     * @returns {object} object
     */
    async getloginaccesspass(req, res) {
        function randomPass() {
            const charSet = '0123456789';
            let randomString = '';
            for (let i = 0; i < 6; i++) {
                const randomPoz = Math.floor(Math.random() * charSet.length);
                randomString += charSet.substring(randomPoz, randomPoz + 1);
            }
            return randomString;
        }
        const user = req.user;
        const accessPass = randomPass();
        const hashAccess = Helper.hashPassword(accessPass);
        const updateQuery = 'UPDATE users set accesspass = $1 where id = $2 returning *';
        try {
            const { rows } = await db.query(updateQuery, [hashAccess, user.id]);
            if (!rows[0]) {
                return res.status(400).send({'message': 'Error Update user'});
            }
            const sendMessage = 'Hello, \nThe access pass is: ' + accessPass;
            const mailOptions = {
                from: 'BoostConnect <boost@bnppboostchange.com>',
                to: user.email,
                subject: 'BoostConnect Access Pass',
                text: sendMessage,
            };
            const result = await utils.sendEmail(mailOptions);
            if (result) {
                return res.status(200).send({message: 'email sent successfull'});
            } else {
                return res.status(401).send({'message': 'error sent email'});
            }
        } catch (err) {
            return res.status(401).send(err);
        }
    },

    /**
     * Logout
     * @param {object} req
     * @param {number} req.user.id
     * @param {string} req.token
     * @param {object} res
     * @returns {object} user object
     */
    async logout(req, res) {
        const userId = req.user.id;
        const token = req.token;
        try {
            const removeQuery = 'Delete from authentification where userId = $1 and token = $2 returning *';
            const { rows } = await db.query(removeQuery, [userId, token]);
            if (!rows[0]) {
                return res.status(401).send({'message': 'Error Logout user'});
            }
            return res.status(200).send({ message: 'Logout success' });
        } catch (error) {
            return res.status(401).send(error);
        }
    },

    /**
     * Refresh Token
     * @param {object} req
     * @param {object} req.user
     * @param {{uuid: string}} req.application
     * @param {object} res
     * @returns {object} user object
     */
    async refreshToken(req, res) {
        const user = req.user;
        const application = req.application;
        const obj = {
            userId: user.id,
            application: application.uuid,
        };
        const token = Helper.generateToken(obj);
        /** @type {object} */
        const decoded = await jwt.verify(token, process.env.SECRET);
        const refreshToken = Helper.generateRefreshToken(user.id);
        const expiration = new Date(0);
        expiration.setUTCSeconds(decoded.exp);
        try {
            const createQuery = 'INSERT INTO authentification(userId, applicationId, token, refreshtoken, expiration) VALUES($1, $2, $3, $4, $5) returning *';
            const { rows } = await db.query(createQuery, [user.id, application.id, token, refreshToken, expiration]);
            if (!rows[0]) {
                return res.status(401).send({'message': 'Error Refresh Token'});
            }
            return res.status(200).send({ token, refreshToken });
        } catch (e) {
            return res.status(401).send(e);
        }
    },

    /**
     * Check Token
     * @param {object} req
     * @param {object} res
     * @returns {object} user object
     */
    async checkToken(req, res) {
        return res.status(200).send({ message: 'user grant success' });
    },
};

export default Authentification;

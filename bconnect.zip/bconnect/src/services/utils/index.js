import nodemailer from 'nodemailer';

const Utils = {
    /**
     * Send Email
     * @param {object} mailOptions
     * @returns {object} object
     */
    sendEmail(mailOptions){
        /** @type {object} */
        const transporter = nodemailer.createTransport({
            host: '',
            port: 123,
            secureConnection: false,
            auth: {
                user: '',
                pass: '',
            },
            tls: {
                ciphers: '',
            },
        });
        return new Promise((resolve, reject) => {
            transporter.sendMail(mailOptions, function (errSend, info) {
                transporter.close();
                if (errSend) {
                    reject(errSend);
                }
                if (info && info.response) {
                    resolve(true);
                } else {
                    reject({message: 'error sent email'});
                }
            });
        });
    }
};

export default Utils;
